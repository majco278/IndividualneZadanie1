﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Autobazar
    {

        static string[] Cars = new string[5];           //instancie zacinaju malym
        Menu Menu = new Menu();
        



        public static void CreateCar(int price, int km, int rok, string mesto, int pocetDveri, bool havarovane, Car.Znacka znacka, Car.Typ typ, Car.Palivo palivo)
        {
            StringBuilder sb = new StringBuilder();
            Car car = new Car(price, km, rok, mesto, pocetDveri, havarovane, znacka, typ, palivo);
            Cars[0] = car.DescribeMe();                 //ukladanie do indexu 0 v poli auta, metodu describe me, ktora mi vrati string a ten sa ulozi
            Console.WriteLine(Cars[0]);
            Console.ReadLine();
            ConsoleApp12.Menu.Option();
            
        }

       

        public static void DeleteCar()
        {

            Menu.Option();
        }

        public static void ChangeInfo()
        {

            Menu.Option();
        }
        
    }

}
